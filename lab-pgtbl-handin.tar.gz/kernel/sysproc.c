#include "types.h"
#include "riscv.h"
#include "param.h"
#include "defs.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;


  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}


#ifdef LAB_PGTBL
int
sys_pgaccess(void)
{
  // lab pgtbl: your code here.
  // 获取要检查的虚拟地址的起始地址
  uint64 addr;
  argaddr(0, &addr);
  //获取需要检查的页面的数量
  int num;
  argint(1, &num);
  uint64 bits = 0;

  uint64 bitaddr = 0;
  argaddr(2,&bitaddr);
  pagetable_t pagetable = myproc()->pagetable;
  pte_t *pte_p;
  for(int i = 0;i < num;i++)
  {
    pte_p = walk(pagetable, addr, 0);
    // printf("虚拟地址:%p对应的页表项:%p\n",addr,(*pte_p));
    if(*(pte_p) & PTE_A)
    {
      bits   = bits | (1L<<i);
    }
    addr = (((addr >> 12)+1)<<12);
  }
  bits  =  bits ^ myproc()-> lastbits;
  myproc() -> lastbits = bits;
  // printf("bits:%p\n",bits);
  // printf("---------------\n\n");
  copyout(pagetable,bitaddr,(char *)&bits,sizeof(bits));
  return 0;
}
#endif

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
