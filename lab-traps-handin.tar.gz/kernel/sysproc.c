#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  backtrace();
  int n;
  uint ticks0;
  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}


//处理alarm的调用
uint64 sys_sigalarm(void)
{ 
  struct proc*proc = myproc();
  int ticks = 0;
  argint(0,&ticks);
  uint64 hander_addr = 0;
  argaddr(1,&hander_addr);//取得的是用户的虚拟地址
  proc->isuse = 0;//没有在使用
  proc->ticks = ticks;
  proc->hander_addr = hander_addr;
  //保存当前寄存器的信息
  proc->ticks_p = 0;
  // proc->s_epc = proc->trapframe->epc;


  // printf("%x",proc->trapframe->a0);

  return 0;
}
//处理alaem的返回
uint64 sys_sigreturn(void)
{
  struct proc*proc = myproc();
  //结束调用
  // intr_off();
  // proc->ticks = 0;
  // proc->hander_addr = 0;
  // proc->ticks_p = 0;
  //恢复寄存器信息
  proc->trapframe->ra = proc->s_ra;
  proc->trapframe->sp = proc->s_sp;
  proc->trapframe->gp = proc->s_gp;
  proc->trapframe->tp = proc->s_tp;
  proc->trapframe->t0 = proc->s_t0;
  proc->trapframe->t1 = proc->s_t1;
  proc->trapframe->t2 = proc->s_t2;
  proc->trapframe->s0 = proc->s_s0;
  proc->trapframe->s1 = proc->s_s1;
  proc->trapframe->a0 = proc->s_a0;
  proc->trapframe->a1 = proc->s_a1;
  proc->trapframe->a2 = proc->s_a2;
  proc->trapframe->a3 = proc->s_a3;
  proc->trapframe->a4 = proc->s_a4;
  proc->trapframe->a5 = proc->s_a5;
  proc->trapframe->a6 = proc->s_a6;
  proc->trapframe->a7 = proc->s_a7;
  proc->trapframe->s2 = proc->s_s2;
  proc->trapframe->s3 = proc->s_s3;
  proc->trapframe->s4 = proc->s_s4;
  proc->trapframe->s5 = proc->s_s5;
  proc->trapframe->s6 = proc->s_s6;
  proc->trapframe->s7 = proc->s_s7;
  proc->trapframe->s8 = proc->s_s8;
  proc->trapframe->s9 = proc->s_s9;
  proc->trapframe->s10 =proc->s_s10;
  proc->trapframe->s11 =proc->s_s11;
  proc->trapframe->t3 = proc->s_t3;
  proc->trapframe->t4 = proc->s_t4;
  proc->trapframe->t5 = proc->s_t5;
  proc->trapframe->t6 = proc->s_t6;
  //恢复epc
  proc->trapframe->epc = proc->s_epc;
  proc->isuse = 0;//没有在使用

  // intr_on(); 
  return proc->trapframe->a0;//最后这里需要返回a0的值，因为a0是原来的返回值
}