#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <pthread.h>
#include <sys/time.h>

#define NBUCKET 5
#define NKEYS 100000

struct entry {
  int key;
  int value;
  struct entry *next;
};
struct entry *table[NBUCKET];
int keys[NKEYS];
int nthread = 1;

pthread_mutex_t lock[NBUCKET];            // declare a lock

double
now()
{
 struct timeval tv;
 gettimeofday(&tv, 0);
 return tv.tv_sec + tv.tv_usec / 1000000.0;
}

static void 
insert(int key, int value, struct entry **p, struct entry *n)
{
  struct entry *e = malloc(sizeof(struct entry));//申请项
  e->key = key;//设置关键字
  e->value = value;//设置值
  e->next = n;//设置下一个
  *p = e;
}

static 
void put(int key, int value)
{

  int i = key % NBUCKET;//决定在哪个槽里面
  pthread_mutex_lock(&lock[i]);    

  // is the key already present?检查关键字是否已经设置了
  struct entry *e = 0;
  // pthread_mutex_lock(&lock);       // acquire lock
  for (e = table[i]; e != 0; e = e->next) {
    if (e->key == key)
    {
      break;
    }
  }
  if(e){
    // update the existing key.更新已经存在的关键字
    e->value = value;
    // pthread_mutex_unlock(&lock);     // release lock
  } else {
    // the new is new.最新的就是新的
    insert(key, value, &table[i], table[i]);
  }
  pthread_mutex_unlock(&lock[i]); 
}

static struct entry*
get(int key)
{
  int i = key % NBUCKET;


  struct entry *e = 0;
  // pthread_mutex_lock(&lock);       // acquire lock
  for (e = table[i]; e != 0; e = e->next) {
    if (e->key == key) break;
  }
  // pthread_mutex_unlock(&lock);     // release lock

  return e;
}

static void *
put_thread(void *xa)
{
  int n = (int) (long) xa; // thread number
  int b = NKEYS/nthread;

  for (int i = 0; i < b; i++) {
    put(keys[b*n + i], n);
  }

  return NULL;
}

static void *
get_thread(void *xa)
{
  int n = (int) (long) xa; // thread number
  int missing = 0;

  for (int i = 0; i < NKEYS; i++) {
    struct entry *e = get(keys[i]);
    if (e == 0) missing++;
  }
  printf("%d: %d keys missing\n", n, missing);
  return NULL;
}

int
main(int argc, char *argv[])
{
  pthread_t *tha;
  void *value;
  double t1, t0;
  for(int i = 0;i < NBUCKET;++i)
  {
    pthread_mutex_init(&lock[i], NULL); // initialize the lock
  }
  if (argc < 2) {
    fprintf(stderr, "Usage: %s nthreads\n", argv[0]);
    exit(-1);
  }
  nthread = atoi(argv[1]);
  tha = malloc(sizeof(pthread_t) * nthread);//在堆上创建线程
  srandom(0);
  assert(NKEYS % nthread == 0);//确保线程的数量是NKEYS的约数
  for (int i = 0; i < NKEYS; i++) {
    keys[i] = random();//将关键字填满
  }

  //
  // first the puts
  //
  t0 = now();
  for(int i = 0; i < nthread; i++) {
    assert(pthread_create(&tha[i], NULL, put_thread, (void *) (long) i) == 0);
  }
  for(int i = 0; i < nthread; i++) {
    assert(pthread_join(tha[i], &value) == 0);
  }
  t1 = now();

  printf("%d puts, %.3f seconds, %.0f puts/second\n",
         NKEYS, t1 - t0, NKEYS / (t1 - t0));

  //
  // now the gets
  //
  t0 = now();//现在的时间
  for(int i = 0; i < nthread; i++) {
    assert(pthread_create(&tha[i], NULL, get_thread, (void *) (long) i) == 0);
  }
  for(int i = 0; i < nthread; i++) {
    assert(pthread_join(tha[i], &value) == 0);
  }
  t1 = now();

  printf("%d gets, %.3f seconds, %.0f gets/second\n",
         NKEYS*nthread, t1 - t0, (NKEYS*nthread) / (t1 - t0));
}
