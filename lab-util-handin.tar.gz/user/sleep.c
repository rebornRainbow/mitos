#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"//这里应该有用户态可以调用的系统函数



int main(int argc,char*argv[])
{
  // 检查参数数量
  if(argc != 2)
  {
    fprintf(2,"参数错误!!!sleep <num>\n");
    return -1;
  }
  // 将第二参数转化为数字
  int tick = atoi(argv[1]);
  if(tick == 0)
  {
    fprintf(2,"参数错误!!!sleep <num>\n");
    return -1;
  }
  sleep(tick);
  // 失败处理
  return 0;
}