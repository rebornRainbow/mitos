#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"//这里应该有用户态可以调用的系统函数

#define MAXARG 32

void cout(char **argv)
{
  int i = 0;
  while(argv[i])
  {
    printf("%s|",argv[i++]);
  }
  printf("\n");

}

//读取一个参数
char *readp()
{
  static char buffer[1024];
  int bufi = 0;
  
  char tem = ' ';
  while(tem != '\n')
  {
    int num = read(0,&tem,1);
    if(num == -1 || tem == ' ')
    {
      return 0;
    }
    buffer[bufi++] = tem;
    // printf("bufi=%d,%c\n",bufi,tem);
    // sleep(1);
  }
  buffer[--bufi] = '\0';
  return buffer;
}



int xagrs(int argc,char *argv[])
{
  char * p = readp();
  char *arg[MAXARG];

  if(p == 0)
    return -1;
  // printf("%s\n",p);
  if(fork() == 0)
  {
    argv[argc] = p;
    for(int i = 1;i <= argc;++i)
    {
      arg[i-1] = argv[i];
    }
    arg[argc] = 0;
    // argv[argc+1] = 0;
    
    // ++argv;
    // cout(arg);
    int err = exec(arg[0],arg);
    printf("fail exec!:%d\n",err);
    exit(-1);
  }else
  {
    wait(0);
    return 0;
  }
  
}


int main(int argc,char*argv[])
{

  int num = 0;
  while(num != -1)
  {
    num = xagrs(argc,argv);
  }
  return 0;
}